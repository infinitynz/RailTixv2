## RailTix — Rail Credits (Wallet + QR/POS) Specification

Status: Draft v0.2  
Applies to: Credits purchase, ticket checkout, POS deductions, receipts

### 1) Goals
- Let users purchase Rail Credits and spend them on tickets or on-site POS.
- Provide QR-based scanning for fast credit deductions at events.
- Keep credits scoped to the Event Manager who issued them.
- Provide receipts, audit logs, and balance tracking.

### 2) Credit System Scope
- Each **Event Manager** has their own **Credit Program**.
- Credits are **not transferable** across Event Managers.
- Event Managers can enable/disable their credit program and set a program name.
- Admin can manually adjust user balances (credit/debit).

### 3) Exchange Rate and Pricing
- Fixed rate: **2 Credits = $1 NZD**.
- Rate is not dynamic and does not change per event.
- Event Managers set **two prices** for tickets:
  - Price in dollars
  - Price in credits
- No extra percentage discount logic; pricing is explicit.

### 4) Minimum/Maximum Top-Up
- Minimum top-up: **$10 NZD**
- Maximum top-up: **$500 NZD**
- Top-ups use Stripe only (no alternate payment methods).
- Top-up purchases generate a receipt/invoice like a ticket purchase.

### 5) Wallet and Ledger Model
Core entities:
- **CreditProgram**
  - EventManagerId, Name, IsEnabled, RateCreditsPerNZD (fixed = 2)
- **CreditWallet**
  - UserId, CreditProgramId, BalanceCredits, UpdatedAt
- **CreditTransaction**
  - Id, UserId, CreditProgramId
  - Type: Purchase | Deduct | Refund | Adjustment
  - AmountCredits (positive; sign implied by Type)
  - AmountNZD (optional, for reconciliation)
  - Reference (payment intent id, order id, POS ref)
  - IdempotencyKey
  - CreatedAt, CreatedBy (user/admin/system)
  - ReversalOfTransactionId (for refunds/voids)

### 6) User Flows
1) **Buy Credits**
   - User selects Credit Program (dropdown, prefilled by purchase history).
   - Choose amount ($10–$500).
   - Pay via Stripe → webhook confirms.
   - CreditTransaction(Purchase) created → wallet balance updated.
   - Receipt emailed.

2) **Buy Ticket with Credits**
   - If Event Manager has credits enabled, show credit price option.
   - If user has enough credits → deduct and complete order.
   - If not enough credits → user must top up (no split with Stripe).
   - Refunds return credits to the same Credit Program.

3) **POS Deduction at Event**
   - Event Manager logs into POS view.
   - User displays wallet QR token.
   - Scan → confirm screen (amount, balance, event details).
   - Confirm → CreditTransaction(Deduct) and balance update.
   - Email receipt sent to user.
   - Log entry visible in Event Manager account area.

### 7) QR Token Rules
- Token validity: **120 seconds**.
- Token contains: user id, credit program id, issued-at, expiry, nonce, jti.
- Signed token (HMAC/JWS).
- UI shows countdown and auto-refresh when expired.

### 8) Security & Integrity
- Signed QR with anti-replay (track jti for expiry window).
- Idempotency for POS deductions and top-ups.
- Online-only POS flow (assume internet availability).
- POS access: Event Manager only (global role).
- Audit log for all adjustments and deductions.

### 9) Refunds and Adjustments
- Ticket refunds return credits to the same program.
- Admin can manually credit or debit users.
- Declined/failed Stripe payments do not create credits.
- Manual credit/debit always logged with reason.

### 10) Receipts and Logs
- Email receipt for:
  - Credit purchase
  - POS deduction
- Receipt includes:
  - Event name, venue, date/time
  - Amount in credits and NZD equivalent
  - Staff/user identifier
  - Transaction id
- Event Managers can view transaction logs for their program.

### 11) UI Requirements
- Credit Program selection dropdown at top-up.
- Show balance per credit program in account area.
- POS confirm screen with final amount and remaining balance.
- Admin tools to enable/disable program and adjust balances.

### 12) Reporting
- Ledger export by date/type.
- Summaries per event manager (credits sold, spent, refunded).
- Top-up totals via Stripe reconciliation.

### 13) Open Items
- Whether to allow users to transfer credits between programs (default: no).
- Whether to allow admin override of the exchange rate (default: no).

