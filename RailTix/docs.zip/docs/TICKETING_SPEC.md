## RailTix — Ticketing Core Specification (Hi.Events-Derived)

Status: Draft v0.1  
Applies to: Event creation, ticketing, checkout, orders, payments, attendees, check-in

Reference implementation in this repo (Hi.Events):
- `hi.events.full/backend/docs/database-schema.md`
- `hi.events.full/backend/docs/architecture-overview.md`
- `hi.events.full/backend/docs/events-and-jobs.md`
- `hi.events.full/frontend/src/types.ts`
- `hi.events.full/frontend/src/router.tsx`
- `hi.events.full/frontend/src/components/routes/event/HomepageDesigner`
- `hi.events.full/frontend/src/components/routes/event/TicketDesigner`
- `hi.events.full/frontend/src/components/routes/organizer/OrganizerHomepageDesigner`

### 1) Scope and Goals
- Build the core ticketing system inside RailTix (ASP.NET Core MVC, .NET 8) using Hi.Events feature parity where appropriate.
- Integrate with RailTix roles and business logic (Admin is platform owner; Event Managers sell on the platform).
- Provide a clean, secure checkout flow with inventory locking, Stripe Connect payouts, QR tickets, and check-in.
- English-only UI; timezone-aware but no multi-language content.
- No embeddable widgets.
- CMS is separate and should not drive event landing pages.

### 2) Roles, Tenancy, and Ownership
- **Admin**: Platform owner with master Stripe account. Full system access.
- **Event Manager**: Can create/manage their events, connect Stripe account, sell tickets.
- **Site User**: Can buy tickets, manage profile, view orders/tickets.
- **Attendee**: A Site User or guest. Guest attendees can later claim tickets to their account.
- No multi-tenant "account" system; the platform is a single tenant with per-event ownership and access checks.
- If new roles are needed, they must be explicit and map cleanly to the existing role inheritance model.

### 3) Core Domain Entities (RailTix Model)
Mirror the Hi.Events structure but align with RailTix naming and roles.

- **Organizer**: Branding container for a set of events (name, slug, socials, SEO).
- **OrganizerSettings**: Homepage theme, visibility (public/private/password), SEO, social links.
- **Event**: Title, description, dates, status, organizer, owner user, timezone, currency, location, slug.
- **EventSettings**: Event page theme, cover/logo images, SEO, checkout messages, payment settings.
- **Product**: Ticket or add-on (non-ticket product).
- **ProductPrice**: Tiered pricing (early bird, VIP), donation/free/paid.
- **ProductCategory**: Group ticket types (e.g., General, VIP).
- **CapacityAssignment**: Shared capacity across products or event-wide capacity.
- **TaxAndFee**: Configurable taxes/fees, fixed or percentage, inclusive/exclusive display.
- **PromoCode**: Discount codes with usage limits and product restrictions.
- **Order**: Customer purchase, status, totals, payment info, reserved_until.
- **OrderItem**: Product line items with price snapshots.
- **Attendee**: One per ticket; check-in status, QR, personal details.
- **Question / QuestionAnswer**: Custom checkout questions (order-level or attendee-level).
- **CheckInList**: Multiple entry points or time windows.
- **AttendeeCheckIn**: Scan logs with device/staff metadata.
- **StripeAccount / StripePayment**: Connect account and payment intent tracking.
- **Invoice**: Optional invoice generation with numbering and tax details.
- **EventStatistics / EventDailyStatistics**: Aggregated metrics for dashboards.
- **Message**: Bulk messaging by event or ticket type.

### 4) Event Lifecycle and CRUD
- **Statuses**: DRAFT, LIVE, PAUSED, ARCHIVED.
- **Publish rules**:
  - At least one active ticket product with inventory.
  - Stripe Connect complete if card payments are enabled.
  - Offline payments allowed if instructions are set.
- **Event end rule**: Once the event has ended, ticket sales are disabled.
- **Event creation**: Title, start/end, timezone, currency, organizer, location.
- **Event duplication**: Optional (copy settings, products, questions, capacities).
- **Event homepage**: Separate from CMS; driven by EventSettings and organizer branding.

### 5) Event URLs and Routing
- Event URL pattern: `/event/{event-slug}`.
- Slug is generated at creation and can be overridden if available.
- Slug uniqueness across all events and reserved routes.
- URL normalization to lowercase kebab-case; 301 redirect for non-canonical paths.
- If the event is ended, the page remains viewable but "Buy" actions are disabled.

### 6) Organizer Homepage and Branding
- Organizer has a public page listing its events.
- Organizer branding includes:
  - Cover image, logo, accent colors.
  - SEO fields: title, description, keywords, allow indexing.
  - Social links (Facebook, Instagram, etc.).
- Visibility options: public, private, or password protected.

### 7) Ticketing Model (Products)
- **Product types**: Ticket (entry) and General (add-ons).
- **Price types**: Paid, Free, Donation, Tiered.
- **Sale windows**: Start/end per product or price tier.
- **Visibility**: Hidden/locked tickets behind promo codes.
- **Per-order limits**: min/max per order.
- **Capacity assignments**: Shared capacity across multiple products.
- **Price display**: Inclusive or exclusive tax/fees (event setting).
- **Platform fees**: Option to pass platform fees to buyer or absorb.

### 8) Taxes, Fees, and Currency
- Taxes/fees are configurable and can be attached to products.
- Support fixed or percentage amounts.
- Currency stored per event; all totals use event currency.
- Order stores a point-in-time snapshot for taxes/fees, products, and prices.

### 9) Checkout Flow (Public)
1. User selects products on event page.
2. System reserves inventory and creates an order in `RESERVED`.
3. Collect attendee details (per order or per ticket).
4. Apply promo code and compute totals.
5. Payment step (card, credits, or offline).
6. On success: order `COMPLETED`, tickets issued, emails sent.
7. On failure or timeout: reservation expires and inventory is released.

Guest checkout is allowed. If the buyer is not logged in, they can later claim tickets.

### 10) Order Lifecycle and Statuses
- `RESERVED`: Inventory locked; awaiting payment.
- `AWAITING_OFFLINE_PAYMENT`: Offline payment chosen; tickets issued but marked unpaid.
- `COMPLETED`: Payment confirmed.
- `CANCELLED`: Expired or cancelled by event manager/admin.
- `REFUNDED` / `PARTIALLY_REFUNDED`: Refund completed.

### 11) Inventory Locking and Concurrency (Azure/.NET)
The database is the source of truth; keep it simple and safe.

Reservation algorithm (SQL Server / Azure SQL):
- Start a transaction with row locks on `ProductPrice` and any `CapacityAssignment`.
- Atomic update to reserve stock:
  - `UPDATE ProductPrices SET quantity_sold = quantity_sold + @qty`
  - `WHERE id = @id AND quantity_sold + @qty <= initial_quantity_available`
- If zero rows affected, item is sold out.
- Create `Order` with `reserved_until = now + OrderTimeoutMinutes`.
- Commit.

Release and expiry:
- Background job scans for `RESERVED` orders past `reserved_until` and releases inventory.
- On payment success, inventory remains sold; on failure, it is released by expiry.

Idempotency:
- Use `Idempotency-Key` header for order creation and payment confirmation.
- Deduplicate retries on server to prevent duplicate orders or charges.

### 12) Stripe Connect and Payments
Roles:
- **Admin** owns the platform Stripe account.
- **Event Managers** connect their own Stripe accounts.

Flows:
- Event Manager completes Connect onboarding.
- Store `stripe_account_id` and `stripe_connect_setup_complete`.
- If card payments enabled, event cannot go LIVE until Stripe setup is complete.

Card payments (recommended approach):
- Destination charge from platform account with `transfer_data.destination` to connected account.
- `application_fee_amount` for platform fees.
- Use Stripe Payment Intents and webhooks for confirmation.

Offline payments:
- Event-level setting: enable offline payments + instructions.
- Orders are marked `AWAITING_OFFLINE_PAYMENT`.
- Check-in can be allowed or blocked based on event setting.

Refunds:
- Partial or full refunds via Stripe.
- Order totals, event stats, and invoice records updated.

Additional Stripe details:
- See `docs/STRIPE_SPEC.md` for onboarding, payment intent flow, webhooks, and payouts.

### 13) Attendee Management
- An attendee record is created per ticket item.
- Attendee may be linked to a Site User or remain a guest.
- Event Managers can search/filter attendees and export lists.
- Attendee self-edit is optional and controlled by event settings.
- Custom questions can be order-level or attendee-level.

### 14) QR Tickets and Check-In
- QR codes are generated per attendee ticket (signed, short ID).
- Multiple check-in lists per event (door/session).
- Scan results:
  - First scan marks as checked in and logs time/device/user.
  - Duplicate scan shows prior check-in info.
- Offline scanning:
  - Allowed with local list cache.
  - Sync when back online; conflicts resolved by first check-in timestamp.

### 15) Email and PDF Tickets
- Order confirmation email includes ticket PDF and QR codes.
- Ticket design is configurable (logo, colors, footer text).
- Unpaid offline orders show "Awaiting Payment" on ticket.
- Resend tickets available to Event Manager and Admin.

### 16) Dashboard and Reporting
- Event dashboards show:
  - Views, unique views
  - Sales totals (gross, tax, fee, net)
  - Orders, attendees, refunds
- Daily stats chart for the event.
- Admin dashboards aggregate across all events.
- Exports: orders, attendees, question answers, promo codes (CSV/XLSX).

### 17) Exclusions (Not in v1)
- Embeddable widgets.
- Multi-language UI.
- Affiliates.
- External webhooks (non-Stripe).

### 18) Open Decisions / Questions
- Stripe Connect type (Standard vs Express vs Custom).
- Offline payment handling: allowed to check in or not.
- Invoice numbering scope (global vs per organizer).
- Ticket transfer rules (allow name transfer or not).


